const PAGES = {
    SPLASH_PAGE: 'splash-page',
    ONBOARD_PAGE: 'onboard-page'
}

export default PAGES;